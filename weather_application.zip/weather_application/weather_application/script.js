window.onload = async function () {
  const params = new URLSearchParams(window.location.search);
  const city = params.get("city");
  const apiKey = "e4f769ff2ab8d50ee689d940944f2d00";// Replace with your OpenWeather key

  if (!city) {
    alert("City not provided in URL.");
    return;
  }

  const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  try {
    const response = await fetch(apiURL);
    const data = await response.json();

    if (data.cod !== 200) {
      alert("API error: " + data.message);
      return;
    }

    document.getElementById("cityName").textContent = data.name;
    document.getElementById("description").textContent = data.weather[0].description;
    document.getElementById("temperature").textContent = `${data.main.temp}°C`;
    document.getElementById("feelsLike").textContent = `${data.main.feels_like}°C`;
    document.getElementById("humidity").textContent = `${data.main.humidity}%`;
    document.getElementById("wind").textContent = `${data.wind.speed} m/s`;
    document.getElementById("pressure").textContent = `${data.main.pressure} hPa`;
    document.getElementById("country").textContent = data.sys.country;
    document.getElementById("coordinates").textContent = `${data.coord.lat}, ${data.coord.lon}`;
    document.getElementById("sunrise").textContent = new Date(data.sys.sunrise * 1000).toLocaleTimeString();
    document.getElementById("sunset").textContent = new Date(data.sys.sunset * 1000).toLocaleTimeString();

    // Update Map iframe
    const lat = data.coord.lat;
    const lon = data.coord.lon;
    const mapURL = `https://embed.windy.com/embed2.html?lat=${lat}&lon=${lon}&detailLat=${lat}&detailLon=${lon}&width=650&height=450&zoom=7&level=surface&overlay=wind&menu=&message=true&marker=true`;
    document.getElementById("mapFrame").src = mapURL;

  } catch (err) {
    alert("Error fetching weather data.");
    console.error("Fetch error:", err);
  }
};
